num=int(input("Enter the number"))
a=1
while num>=1:
    a=a*num
    num=num-1
print(a)
