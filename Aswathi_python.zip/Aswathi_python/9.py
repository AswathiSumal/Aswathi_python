num=int(input("Enter a number:"))
length=len(str(num))
sum=0
temp=num
while (temp!=0):
    sum=sum+((temp%10)**length)
    
if num==sum:
    print(num,"is an armstrong")
else:
    print(num,"is not an armstrong")

