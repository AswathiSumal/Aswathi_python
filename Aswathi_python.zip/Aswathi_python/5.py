num1=int(input("Enter a  number 1:"))
num2=int(input("Enter a number 2:"))
temp=num1
num1=num2
num2=temp
print("number after swapping 1",num1)
print("number after swapping 2",num2)
