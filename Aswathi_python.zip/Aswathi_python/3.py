num=int(input("Enter the number"))
if num%2==0:
    print("Even number")
else:
        print("Odd number")
        
