num1=25
num2=25
sum=num1+num2
print(sum)
